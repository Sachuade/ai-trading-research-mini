# Thinking Note

**Question:** "Does buying NIFTY after a sharp fall work?"

## 1. How would I interpret the question?

"Sharp fall" has no fixed meaning — it could mean a single-day drop, a drop
over a week, a drop relative to recent volatility, or a drop from a recent
high. Before testing anything I need to pin down:

- **Magnitude**: what percentage move counts as "sharp"? A 1% day is normal;
  a 3% day is not.
- **Window**: is the fall measured over one session, or accumulated over
  several days?
- **Relative vs. absolute**: is a 1.5% fall "sharp" on a calm day but
  unremarkable during an already-volatile week? A relative (volatility-scaled)
  definition and an absolute one will select different days and can give
  opposite answers.
- **What "work" means**: a positive average return? A positive return more
  often than not? Beating buy-and-hold? Positive after costs? These are not
  the same question, and "does it work" is ambiguous between them.

My working interpretation: a fall of roughly the size that happens
infrequently (not every week) — I used **≥1.5% in a single session** as a
concrete anchor, because it's large enough to be a genuine event but frequent
enough (roughly one every couple of weeks in normal markets) to produce a
usable sample size. This is a judgment call, and the system says so out loud
rather than treating it as fact.

## 2. What assumptions would I make, and where do they come from?

| | Category |
|---|---|
| "NIFTY" | **User said** — instrument is given |
| "sharp fall" | **User said** the *direction* (a fall); **I assumed** the *magnitude* (1.5%, single day) |
| Entry timing | **I assumed** — buy at the close of the signal day (simplest, avoids intraday data I don't have) |
| Exit rule | **I assumed** — fixed holding period (5 trading days), since the user gave no exit condition at all |
| Test period / data source | **I assumed** — since there's no live market data connector in this environment, I used a simulated 5-year daily series and say so explicitly rather than pretending it's real NIFTY history |
| Costs | **I assumed** — a flat ~8bps round-trip (slippage + transaction cost), a conservative placeholder, not a real brokerage's fee schedule |
| What "work" means | **I assumed** — average forward return and win rate, compared against simply holding the index over the same period |

Nothing above is presented as the user's own statement in the UI — each
assumed value is logged with the specific number used and *why*, and the
person can overwrite it before the experiment runs (the CLARIFY step).

**What the system should ask the user** (the genuinely load-bearing
questions, in priority order):
1. What size fall should count as "sharp"?
2. How long should the position be held?
3. Should this only apply during high-volatility periods, or always?
4. What real dataset (if any) should this eventually run against?

## 3. What would I ask the user?

Only the questions above materially change the result. I deliberately did
**not** ask about things like exact holding period *tie-breaking* rules or
weekend handling — those are true edge cases that would clutter a first
interaction without changing the conclusion. The bar I used: *would a
different reasonable answer here flip or meaningfully shift the result?*
If yes, ask (or surface the assumption prominently). If no, assume silently
and move on.

## 4. What would the experiment look like?

- **Market / instrument**: NIFTY 50, daily closing prices.
- **Entry condition**: close-to-close fall ≥ configurable threshold
  (default 1.5%) over a configurable lookback (default 1 day).
- **Optional filter**: restrict to sessions where trailing 20-day realized
  volatility is in the top 30% (a rough proxy for "high-volatility regime").
- **Exit condition**: fixed holding period (default 5 trading days) —
  chosen over a trailing-stop or target because it's the simplest rule that
  still lets us measure "does buying after a fall tend to pay off", without
  introducing a second free parameter (a stop-loss level) that would need
  its own justification.
- **Test period**: a full market cycle if possible (includes both bull and
  bear stretches) — in this prototype, a simulated 5-year daily series,
  since no real data feed is wired up.
- **Costs**: slippage + transaction cost per round trip, applied to every
  trade so the reported edge is net, not gross.
- **Output**: number of trades, win rate, average/median return per trade,
  cumulative strategy return vs. buy-and-hold, and — critically — a
  separation between "what the numbers show" and "what we conclude from
  them."

## 5. What could go wrong?

- **Ambiguous definitions**: a different "sharp" threshold or holding
  period can flip the conclusion entirely. A single backtest is really a
  backtest of *one specific parameter combination*, not of "the strategy."
- **Small sample / insufficient evidence**: a rare-event condition (like a
  1.5%+ fall) might only fire a few dozen times even over years of data.
  A 60% win rate on 20 trades is close to a coin flip's confidence interval.
- **Overfitting**: if someone tries many thresholds/holding periods and
  reports only the best one, the result is guaranteed to look good and is
  guaranteed to be mostly noise. The system should discourage
  parameter-shopping, or at least disclose it when it happens.
- **Look-ahead bias**: using information not actually available at the
  time of the trade (e.g. using the day's close to decide the day's close
  price is itself borderline — a live system would need to trade at the next
  session's open, not the same close, to be realistic).
- **Regime dependence**: a "buy the dip" edge that held in a multi-year bull
  market may disappear or reverse in a prolonged bear market. One test
  window is not proof of a durable edge.
- **Transaction costs & slippage**: an edge that looks real gross-of-costs
  can vanish once realistic costs are applied, especially for short holding
  periods with many small trades.
- **Data quality**: real index data has corporate actions, circuit breakers,
  and gaps; simulated data (as used here) has none of the real market's
  structural quirks, so results here should never be read as a claim about
  the real NIFTY.
- **Survivorship / index reconstitution**: not directly relevant to an index
  price series, but worth flagging if this were extended to individual
  stocks.

The prototype's LEARN step is built specifically to keep "what the data
shows" (a few numbers) separate from "what we conclude" (an interpretation,
qualified by sample size and caveats) — because collapsing those two into one
sentence is, in my view, the single easiest way for a tool like this to
mislead a user.
