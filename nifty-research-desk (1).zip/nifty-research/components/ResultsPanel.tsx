"use client";

import type { BacktestResult, Experiment } from "@/lib/types";

function fmt(n: number, digits = 2) {
  return `${n >= 0 ? "+" : ""}${n.toFixed(digits)}%`;
}

function EquitySparkline({ curve }: { curve: BacktestResult["equityCurve"] }) {
  if (curve.length < 2) return null;
  const w = 560;
  const h = 140;
  const allVals = curve.flatMap((p) => [p.strategy, p.buyHold]);
  const min = Math.min(...allVals);
  const max = Math.max(...allVals);
  const range = max - min || 1;

  const toPoints = (key: "strategy" | "buyHold") =>
    curve
      .map((p, i) => {
        const x = (i / (curve.length - 1)) * w;
        const y = h - ((p[key] - min) / range) * h;
        return `${x},${y}`;
      })
      .join(" ");

  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="w-full h-36">
      <polyline points={toPoints("buyHold")} fill="none" stroke="#6B7280" strokeWidth="1.5" strokeDasharray="3,3" />
      <polyline points={toPoints("strategy")} fill="none" stroke="#B8912A" strokeWidth="2" />
    </svg>
  );
}

function buildNextQuestions(experiment: Experiment, result: BacktestResult): string[] {
  const qs: string[] = [];
  if (result.stats.numTrades < 30) {
    qs.push("Widen the test period or loosen the threshold to see if the sample size holds up.");
  }
  if (experiment.filters.highVolatilityOnly) {
    qs.push("Compare against the same condition without the volatility filter — is the filter actually adding anything?");
  } else {
    qs.push("Check whether the effect is concentrated in high-volatility periods rather than present everywhere.");
  }
  qs.push("Test a few different holding periods (e.g. 1, 3, 10 days) to see how sensitive the result is to that choice.");
  qs.push("Re-run on a different historical window to check the result isn't specific to one market regime.");
  return qs;
}

export default function ResultsPanel({
  experiment,
  result,
  onStartOver,
}: {
  experiment: Experiment;
  result: BacktestResult;
  onStartOver: () => void;
}) {
  const { stats } = result;
  const edgeVsBuyHold = stats.cumulativeReturnPct - stats.buyAndHoldReturnPct;

  return (
    <div className="max-w-2xl">
      <h2 className="font-serif text-2xl text-ink">What the data shows</h2>

      <div className="mt-4 grid grid-cols-2 sm:grid-cols-3 gap-px bg-line border border-line rounded-sm overflow-hidden">
        {[
          { label: "Trades found", value: String(stats.numTrades) },
          { label: "Win rate", value: `${stats.winRatePct.toFixed(1)}%` },
          { label: "Avg return / trade", value: fmt(stats.avgReturnPct) },
          { label: "Median return / trade", value: fmt(stats.medianReturnPct) },
          { label: "Best / worst trade", value: `${fmt(stats.bestReturnPct)} / ${fmt(stats.worstReturnPct)}` },
          { label: "Strategy vs buy-&-hold", value: fmt(edgeVsBuyHold) },
        ].map((s) => (
          <div key={s.label} className="bg-paper p-4">
            <div className="text-[11px] text-muted uppercase tracking-wide">{s.label}</div>
            <div className="font-serif text-xl text-ink mt-1">{s.value}</div>
          </div>
        ))}
      </div>

      <div className="mt-6">
        <div className="flex items-center gap-4 text-xs text-muted mb-2">
          <span className="flex items-center gap-1.5">
            <span className="inline-block w-3 h-0.5 bg-gold" /> Strategy (compounding, non-overlapping trades)
          </span>
          <span className="flex items-center gap-1.5">
            <span className="inline-block w-3 h-0.5 bg-muted" style={{ borderTop: "1px dashed #6B7280" }} /> Buy &amp; hold
          </span>
        </div>
        <div className="bg-white border border-line rounded-sm p-3">
          <EquitySparkline curve={result.equityCurve} />
        </div>
      </div>

      <h3 className="font-serif text-xl text-ink mt-10">What we can reasonably conclude</h3>
      <p className="text-sm text-ink/90 mt-2 leading-relaxed">
        {stats.numTrades < 15
          ? "There isn't enough data here to conclude anything with confidence — this reads as a hint at best, not evidence of an edge."
          : stats.avgReturnPct > 0 && stats.winRatePct > 50
          ? `On this simulated series, the condition was followed by a positive average return more often than not (${stats.winRatePct.toFixed(0)}% of the time). That's consistent with the mean-reversion hypothesis, but it's one dataset and one set of parameter choices — see the caveats before treating this as an edge.`
          : "On this simulated series, the condition did not show a clear positive edge over simply holding the index. That doesn't rule out an edge under different parameters, filters, or a real dataset — it just wasn't visible here."}
      </p>

      <h3 className="font-serif text-xl text-ink mt-8">What to investigate next</h3>
      <ul className="mt-2 flex flex-col gap-1.5">
        {buildNextQuestions(experiment, result).map((q) => (
          <li key={q} className="text-sm text-ink/90 pl-4 relative before:content-['—'] before:absolute before:left-0 before:text-muted">
            {q}
          </li>
        ))}
      </ul>

      <div className="mt-8 bg-white border border-line rounded-sm p-4">
        <div className="text-xs text-muted uppercase tracking-wide mb-2">Why you shouldn't over-trust this</div>
        <ul className="flex flex-col gap-1.5">
          {result.caveats.map((c) => (
            <li key={c} className="text-xs text-muted leading-relaxed pl-4 relative before:content-['·'] before:absolute before:left-0">
              {c}
            </li>
          ))}
        </ul>
      </div>

      <button onClick={onStartOver} className="mt-8 text-sm text-muted underline underline-offset-4">
        Ask a different question
      </button>
    </div>
  );
}
