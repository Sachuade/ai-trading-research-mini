"use client";

import type { Experiment } from "@/lib/types";

export default function ExperimentCard({
  experiment,
  source,
  onRunTest,
  onEditAgain,
  loading,
}: {
  experiment: Experiment;
  source: "llm" | "rule-based-fallback";
  onRunTest: () => void;
  onEditAgain: () => void;
  loading: boolean;
}) {
  const rows: { label: string; value: string }[] = [
    { label: "Instrument", value: experiment.instrument },
    { label: "Timeframe", value: experiment.timeframe },
    { label: "Condition", value: experiment.condition.label },
    { label: "Entry", value: experiment.entry },
    { label: "Exit", value: experiment.exit },
    { label: "Holding period", value: `${experiment.holdingPeriodDays} trading days` },
    { label: "Test period", value: experiment.testPeriod.label },
    {
      label: "Filters",
      value: experiment.filters.highVolatilityOnly
        ? `High-volatility sessions only (top ${100 - experiment.filters.volatilityPercentileThreshold}% by ${experiment.filters.volatilityLookbackDays}-day rolling volatility)`
        : "None",
    },
    {
      label: "Costs",
      value: `${experiment.costAssumptions.slippageBps}bps slippage + ${experiment.costAssumptions.transactionCostBps}bps transaction cost per trade`,
    },
  ];

  return (
    <div className="max-w-2xl">
      <div className="flex items-baseline justify-between">
        <h2 className="font-serif text-2xl text-ink">The experiment</h2>
        <span className="text-[11px] text-muted">
          {source === "llm" ? "structured by LLM" : "structured by rule-based fallback"}
        </span>
      </div>

      <blockquote className="mt-3 font-serif text-lg text-ink/90 border-l-2 border-gold pl-4">
        “{experiment.rawQuestion}”
      </blockquote>

      <div className="mt-6 bg-white border border-line rounded-sm px-4">
        {rows.map((r) => (
          <div key={r.label} className="ledger-row">
            <div className="text-xs text-muted uppercase tracking-wide">{r.label}</div>
            <div className="text-sm text-ink leading-relaxed">{r.value}</div>
          </div>
        ))}
      </div>

      <div className="mt-5 bg-white border border-line rounded-sm p-4">
        <div className="text-xs text-muted uppercase tracking-wide">Hypothesis</div>
        <div className="text-sm text-ink mt-1 leading-relaxed">{experiment.hypothesis}</div>
      </div>

      <div className="mt-8 flex items-center gap-4">
        <button
          onClick={onRunTest}
          disabled={loading}
          className="bg-ink text-paper text-sm px-5 py-2.5 rounded-sm disabled:opacity-40"
        >
          {loading ? "Running on simulated data…" : "Run this experiment"}
        </button>
        <button onClick={onEditAgain} className="text-sm text-muted underline underline-offset-4">
          Revisit assumptions
        </button>
      </div>
    </div>
  );
}
