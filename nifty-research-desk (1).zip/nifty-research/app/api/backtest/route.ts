import { NextRequest, NextResponse } from "next/server";
import { runBacktest } from "@/lib/backtest";
import type { Experiment } from "@/lib/types";

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null);
  const experiment = body?.experiment as Experiment | undefined;

  if (!experiment) {
    return NextResponse.json({ error: "An experiment definition is required." }, { status: 400 });
  }

  const result = runBacktest(experiment);
  return NextResponse.json(result);
}
