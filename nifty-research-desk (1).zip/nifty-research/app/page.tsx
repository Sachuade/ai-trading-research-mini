"use client";

import { useState } from "react";
import Stepper, { Stage } from "@/components/Stepper";
import AskForm from "@/components/AskForm";
import ClarifyPanel from "@/components/ClarifyPanel";
import ExperimentCard from "@/components/ExperimentCard";
import ResultsPanel from "@/components/ResultsPanel";
import type { AnalyzeResponse, BacktestResult, Experiment } from "@/lib/types";

export default function Home() {
  const [stage, setStage] = useState<Stage>("ask");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [experiment, setExperiment] = useState<Experiment | null>(null);
  const [source, setSource] = useState<AnalyzeResponse["source"]>("rule-based-fallback");
  const [result, setResult] = useState<BacktestResult | null>(null);

  async function handleAsk(question: string) {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ question }),
      });
      if (!res.ok) throw new Error("Couldn't analyze that question. Try rephrasing it.");
      const data: AnalyzeResponse = await res.json();
      setExperiment(data.experiment);
      setSource(data.source);
      setStage(data.experiment.missing.length > 0 ? "clarify" : "define");
    } catch (e: any) {
      setError(e.message ?? "Something went wrong.");
    } finally {
      setLoading(false);
    }
  }

  function handleClarifyConfirm(updated: Experiment) {
    setExperiment(updated);
    setStage("define");
  }

  async function handleRunTest() {
    if (!experiment) return;
    setLoading(true);
    setError(null);
    setStage("test");
    try {
      const res = await fetch("/api/backtest", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ experiment }),
      });
      if (!res.ok) throw new Error("The test run failed. Please try again.");
      const data: BacktestResult = await res.json();
      setResult(data);
      setStage("learn");
    } catch (e: any) {
      setError(e.message ?? "Something went wrong.");
      setStage("define");
    } finally {
      setLoading(false);
    }
  }

  function startOver() {
    setStage("ask");
    setExperiment(null);
    setResult(null);
    setError(null);
  }

  return (
    <main className="min-h-screen bg-paper">
      <header className="border-b border-line px-6 md:px-10 py-4 flex items-baseline justify-between">
        <div className="font-serif text-lg text-ink">NIFTY Research Desk</div>
        <div className="text-xs text-muted">question → experiment → evidence</div>
      </header>

      <div className="px-6 md:px-10 py-10 flex flex-col md:flex-row gap-10 md:gap-16">
        <Stepper current={stage} />

        <div className="flex-1">
          {error && (
            <div className="mb-6 text-sm text-loss border border-loss/30 bg-loss/5 rounded-sm px-4 py-3 max-w-2xl">
              {error}
            </div>
          )}

          {stage === "ask" && <AskForm onSubmit={handleAsk} loading={loading} />}

          {stage === "clarify" && experiment && (
            <ClarifyPanel experiment={experiment} onConfirm={handleClarifyConfirm} />
          )}

          {(stage === "define" || stage === "test") && experiment && (
            <ExperimentCard
              experiment={experiment}
              source={source}
              onRunTest={handleRunTest}
              onEditAgain={() => setStage(experiment.missing.length > 0 ? "clarify" : "define")}
              loading={loading || stage === "test"}
            />
          )}

          {stage === "learn" && experiment && result && (
            <ResultsPanel experiment={experiment} result={result} onStartOver={startOver} />
          )}
        </div>
      </div>
    </main>
  );
}
