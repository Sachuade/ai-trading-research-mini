import type { Experiment, MissingField } from "./types";

// This is a deliberately simple, transparent heuristic parser. It exists so
// the prototype is fully functional and demoable WITHOUT an API key (e.g. in
// front of an interviewer with no internet), and so there is always a
// deterministic fallback if the LLM call fails or times out.
//
// It is intentionally not "smart" — it looks for a few obvious signals
// (percentage figures, the word "volatility", the word "sharp") and otherwise
// falls back to sane defaults, all of which are surfaced to the user as
// `missing` fields rather than being silently assumed.

const DEFAULT_DROP_PCT_FOR_SHARP = 1.5; // our working definition of "sharp"

export function ruleBasedParse(question: string): Experiment {
  const q = question.toLowerCase();
  const missing: MissingField[] = [];

  // --- instrument -----------------------------------------------------
  const instrument = /nifty/.test(q) ? "NIFTY 50" : "NIFTY 50";
  if (!/nifty/.test(q)) {
    missing.push({
      field: "instrument",
      question: "Which instrument or index should this test run on?",
      assumption: "NIFTY 50",
      reason: "No instrument was mentioned in the question; NIFTY 50 is the default for this workspace.",
    });
  }

  // --- drop magnitude ---------------------------------------------------
  let dropPct = DEFAULT_DROP_PCT_FOR_SHARP;
  const pctMatch = q.match(/(\d+(\.\d+)?)\s?%/);
  if (pctMatch) {
    dropPct = parseFloat(pctMatch[1]);
  } else if (/sharp|big|large|significant/.test(q)) {
    missing.push({
      field: "condition.dropPct",
      question: `What counts as a "sharp" fall — what percentage drop should trigger the strategy?`,
      assumption: `${DEFAULT_DROP_PCT_FOR_SHARP}% in a single day`,
      reason:
        '"Sharp" is subjective. We used roughly the 90th percentile of single-day NIFTY moves as a working definition, but this materially changes sample size and results.',
    });
  } else {
    missing.push({
      field: "condition.dropPct",
      question: "What percentage fall should trigger a buy?",
      assumption: `${DEFAULT_DROP_PCT_FOR_SHARP}%`,
      reason: "No threshold was given, so we used a moderate default.",
    });
  }

  // --- lookback window for the fall -------------------------------------
  const lookbackDays = /week/.test(q) ? 5 : 1;
  if (!/day|week|session/.test(q)) {
    missing.push({
      field: "condition.lookbackDays",
      question: "Should the fall be measured over a single day, or over a few days/a week?",
      assumption: "Single day (1 trading session)",
      reason: "No timeframe for the fall itself was specified.",
    });
  }

  // --- volatility filter --------------------------------------------------
  const highVolatilityOnly = /volatil/.test(q);

  // --- holding period -----------------------------------------------------
  let holdingPeriodDays = 5;
  const holdMatch = q.match(/hold(ing)?\s*(for|period)?\s*(\d+)\s*(day|days|week|weeks)/);
  if (holdMatch) {
    const n = parseInt(holdMatch[3], 10);
    holdingPeriodDays = /week/.test(holdMatch[4]) ? n * 5 : n;
  } else {
    missing.push({
      field: "holdingPeriodDays",
      question: "How long should the position be held before exiting?",
      assumption: "5 trading days (1 week)",
      reason: "The question didn't specify an exit rule, so we used a short, common holding period as a starting point.",
    });
  }

  // --- test period ----------------------------------------------------
  missing.push({
    field: "testPeriod",
    question: "What time period should we test over, and using which data source?",
    assumption: "~5 years of simulated daily data (this prototype does not have a live market data feed)",
    reason: "No historical data source is connected in this prototype; results are illustrative only.",
  });

  const experiment: Experiment = {
    instrument,
    timeframe: "Daily",
    condition: {
      label: `${instrument} falls ${dropPct}% or more${lookbackDays > 1 ? ` over ${lookbackDays} trading days` : " in a single session"}`,
      dropPct,
      lookbackDays,
    },
    entry: "Buy at the next session's close after the condition is met",
    exit: `Sell after the holding period elapses (${holdingPeriodDays} trading days)`,
    holdingPeriodDays,
    testPeriod: { label: "Simulated 5-year daily series", days: 1250 },
    filters: {
      highVolatilityOnly,
      volatilityLookbackDays: 20,
      volatilityPercentileThreshold: 70,
    },
    costAssumptions: { slippageBps: 5, transactionCostBps: 3 },
    hypothesis:
      "Buying after a sharp fall produces a positive average forward return over the holding period, i.e. the market tends to mean-revert rather than continue falling.",
    missing,
    rawQuestion: question,
  };

  return experiment;
}
