import type { Experiment } from "./types";

// Thin adapter around the Anthropic Messages API. Kept separate from the
// route handler so the LLM could be swapped (OpenAI, local model, etc.)
// without touching request-handling or the frontend.

const SYSTEM_PROMPT = `You convert an informal natural-language trading question into a structured research experiment definition.

Return ONLY a single JSON object, no prose, no markdown fences, matching exactly this shape:

{
  "instrument": string,
  "timeframe": string,
  "condition": { "label": string, "dropPct": number, "lookbackDays": number },
  "entry": string,
  "exit": string,
  "holdingPeriodDays": number,
  "testPeriod": { "label": string, "days": number },
  "filters": { "highVolatilityOnly": boolean, "volatilityLookbackDays": number, "volatilityPercentileThreshold": number },
  "costAssumptions": { "slippageBps": number, "transactionCostBps": number },
  "hypothesis": string,
  "missing": [ { "field": string, "question": string, "assumption": string, "reason": string } ]
}

Rules:
- Only put something in "missing" if the user's question genuinely did not specify it. For each missing item, propose a specific, reasonable numeric/textual default in "assumption" and explain the reasoning in "reason" — never leave a field blank or say "not specified" in the main structure. The main experiment fields must always be fully populated with your best-assumed values; "missing" is just a transparency log of which of those values were assumed rather than stated.
- Interpret vague words like "sharp fall" using a specific numeric threshold (e.g. a percentage), and log that interpretation as a "missing" item so the user can see and challenge it.
- testPeriod.days should assume a simulated ~5-year daily dataset (1250 trading days) is available, since this prototype has no live data feed — always set it to 1250 unless the user names a different period, and note the data-source limitation in "missing".
- Only assume NIFTY 50 if no instrument is named.
- Keep "label" fields short and human-readable.
- Do not include any text outside the JSON object.`;

export async function llmParse(question: string): Promise<Experiment | null> {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) return null;

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-6",
        max_tokens: 1200,
        system: SYSTEM_PROMPT,
        messages: [{ role: "user", content: question }],
      }),
    });

    if (!response.ok) {
      console.error("Anthropic API error", await response.text());
      return null;
    }

    const data = await response.json();
    const text = data.content?.map((c: any) => c.text || "").join("") ?? "";
    const cleaned = text.replace(/```json|```/g, "").trim();
    const parsed = JSON.parse(cleaned);

    return { ...parsed, rawQuestion: question } as Experiment;
  } catch (err) {
    console.error("llmParse failed, falling back to rule-based parser", err);
    return null;
  }
}
