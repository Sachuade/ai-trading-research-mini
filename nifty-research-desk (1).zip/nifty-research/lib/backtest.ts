import type { BacktestResult, Experiment, Trade } from "./types";
import { getMockSeries } from "./mockData";

function pctChange(a: number, b: number) {
  return ((b - a) / a) * 100;
}

function rollingVolatility(closes: number[], i: number, lookback: number): number {
  const start = Math.max(0, i - lookback);
  const window = closes.slice(start, i + 1);
  if (window.length < 2) return 0;
  const returns: number[] = [];
  for (let j = 1; j < window.length; j++) returns.push(pctChange(window[j - 1], window[j]));
  const mean = returns.reduce((a, b) => a + b, 0) / returns.length;
  const variance = returns.reduce((a, b) => a + (b - mean) ** 2, 0) / returns.length;
  return Math.sqrt(variance);
}

export function runBacktest(experiment: Experiment): BacktestResult {
  const series = getMockSeries(experiment.testPeriod?.days || 1250);
  const closes = series.map((p) => p.close);

  // Pre-compute rolling volatility for every day so the filter is cheap to apply.
  const vols = closes.map((_, i) => rollingVolatility(closes, i, experiment.filters.volatilityLookbackDays));
  const sortedVols = [...vols].sort((a, b) => a - b);
  const volThreshold =
    sortedVols[Math.floor((experiment.filters.volatilityPercentileThreshold / 100) * (sortedVols.length - 1))];

  const trades: Trade[] = [];
  const lookback = Math.max(1, experiment.condition.lookbackDays);
  const holding = Math.max(1, experiment.holdingPeriodDays);
  const costPct = (experiment.costAssumptions.slippageBps + experiment.costAssumptions.transactionCostBps) / 100;

  let i = lookback;
  while (i < closes.length - holding) {
    const change = pctChange(closes[i - lookback], closes[i]);
    const conditionMet = change <= -Math.abs(experiment.condition.dropPct);
    const volOk = !experiment.filters.highVolatilityOnly || vols[i] >= volThreshold;

    if (conditionMet && volOk) {
      const entryIndex = i; // entry at this day's close, per experiment.entry
      const exitIndex = i + holding;
      const entryPrice = closes[entryIndex];
      const exitPrice = closes[exitIndex];
      const grossReturnPct = pctChange(entryPrice, exitPrice);
      const returnPct = grossReturnPct - costPct;

      trades.push({
        entryIndex,
        entryDate: series[entryIndex].date,
        entryPrice,
        exitIndex,
        exitDate: series[exitIndex].date,
        exitPrice,
        returnPct,
        grossReturnPct,
      });

      i = exitIndex; // non-overlapping trades: don't re-enter mid-holding-period
    } else {
      i++;
    }
  }

  const returns = trades.map((t) => t.returnPct);
  const numTrades = trades.length;
  const winRatePct = numTrades ? (returns.filter((r) => r > 0).length / numTrades) * 100 : 0;
  const avgReturnPct = numTrades ? returns.reduce((a, b) => a + b, 0) / numTrades : 0;
  const sorted = [...returns].sort((a, b) => a - b);
  const medianReturnPct = numTrades ? sorted[Math.floor(numTrades / 2)] : 0;
  const bestReturnPct = numTrades ? Math.max(...returns) : 0;
  const worstReturnPct = numTrades ? Math.min(...returns) : 0;

  let compounding = 1;
  const equityCurve: BacktestResult["equityCurve"] = [];
  let bh = 1;
  const bhStart = closes[0];
  trades.forEach((t) => {
    compounding *= 1 + t.returnPct / 100;
    bh = closes[t.exitIndex] / bhStart;
    equityCurve.push({ date: t.exitDate, strategy: compounding, buyHold: bh });
  });
  const cumulativeReturnPct = (compounding - 1) * 100;
  const buyAndHoldReturnPct = pctChange(closes[0], closes[closes.length - 1]);

  const caveats = [
    "This runs on SIMULATED daily data, not real NIFTY prices — treat all numbers as illustrative of the workflow, not as trading advice.",
    "Trades are non-overlapping (we skip ahead past each holding period), which reduces sample size but avoids double-counting overlapping windows.",
    numTrades < 30
      ? `Only ${numTrades} trades were found — that's a small sample, so the win rate and average return could easily be noise rather than a real edge.`
      : "Even with a reasonable trade count, a single backtest window can't rule out that the result is specific to this period's regime.",
    "Costs are modeled as a flat per-trade percentage (slippage + transaction cost); real slippage varies with liquidity and order size.",
    "No look-ahead bias was intentionally introduced (entry uses only data available at the close of the signal day), but this hasn't been independently audited.",
  ];

  return {
    trades,
    stats: {
      numTrades,
      winRatePct,
      avgReturnPct,
      medianReturnPct,
      bestReturnPct,
      worstReturnPct,
      cumulativeReturnPct,
      buyAndHoldReturnPct,
    },
    equityCurve,
    caveats,
  };
}
