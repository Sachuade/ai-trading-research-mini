// Core domain model. Kept deliberately small and explicit so it can be
// swapped later for a real backtesting-engine schema without touching the UI.

export type MissingField = {
  field: string; // e.g. "holdingPeriod"
  question: string; // what we'd ask the user
  assumption: string; // reasonable default we propose instead of blocking the user
  reason: string; // why we chose that default
};

export type Experiment = {
  instrument: string;
  timeframe: string; // e.g. "Daily"
  condition: {
    label: string; // human-readable, e.g. "NIFTY falls >= 1% in a single day"
    dropPct: number; // magnitude of the fall, e.g. 1 for 1%
    lookbackDays: number; // over how many days the fall is measured
  };
  entry: string; // e.g. "Buy at next day's open after condition is met"
  exit: string; // e.g. "Sell after holding period elapses"
  holdingPeriodDays: number;
  testPeriod: {
    label: string; // e.g. "Last 5 years (simulated daily data)"
    days: number;
  };
  filters: {
    highVolatilityOnly: boolean;
    volatilityLookbackDays: number;
    volatilityPercentileThreshold: number; // e.g. 70 = top 30% most volatile days
  };
  costAssumptions: {
    slippageBps: number;
    transactionCostBps: number;
  };
  hypothesis: string;
  // Fields the system inferred/assumed rather than the user stating them directly.
  missing: MissingField[];
  // The literal user question, preserved for traceability.
  rawQuestion: string;
};

export type AnalyzeResponse = {
  experiment: Experiment;
  source: "llm" | "rule-based-fallback";
};

export type Trade = {
  entryIndex: number;
  entryDate: string;
  entryPrice: number;
  exitIndex: number;
  exitDate: string;
  exitPrice: number;
  returnPct: number; // net of costs
  grossReturnPct: number;
};

export type BacktestResult = {
  trades: Trade[];
  stats: {
    numTrades: number;
    winRatePct: number;
    avgReturnPct: number;
    medianReturnPct: number;
    bestReturnPct: number;
    worstReturnPct: number;
    cumulativeReturnPct: number; // compounding all trades sequentially (non-overlapping)
    buyAndHoldReturnPct: number; // over the same test period, for comparison
  };
  equityCurve: { date: string; strategy: number; buyHold: number }[];
  caveats: string[];
};
