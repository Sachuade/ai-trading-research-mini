// We deliberately generate SIMULATED daily price data rather than fetching a
// real feed. NSE/NIFTY historical data isn't reachable from this environment,
// and the assignment explicitly allows simulated/mock data — the point is to
// demonstrate the research workflow, not to produce a production backtest.
//
// The generator is a seeded random walk with a slight upward drift and
// volatility clustering (a simple GARCH-ish trick: volatility itself follows
// a mean-reverting random walk), so it produces realistic-looking "fat
// tailed", volatility-clustered daily returns instead of pure white noise.

import type { } from "./types";

export type PricePoint = { date: string; close: number };

// mulberry32: small, fast, deterministic PRNG so the dataset is reproducible
// across runs (same seed -> same series -> same backtest result every time).
function mulberry32(seed: number) {
  return function () {
    seed |= 0;
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// Box-Muller transform to turn uniform randoms into approximately normal ones.
function gaussian(rand: () => number) {
  const u1 = Math.max(rand(), 1e-9);
  const u2 = rand();
  return Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
}

let cachedSeries: PricePoint[] | null = null;

export function getMockSeries(days = 1250, seed = 42): PricePoint[] {
  // 1250 trading days ~= 5 years. Cache so repeated calls in one server
  // process are consistent and cheap.
  if (cachedSeries && cachedSeries.length === days) return cachedSeries;

  const rand = mulberry32(seed);
  let price = 22000; // arbitrary starting level, roughly NIFTY-scale
  let vol = 0.008; // daily vol, ~0.8%
  const series: PricePoint[] = [];

  const start = new Date();
  start.setDate(start.getDate() - days * 1.45); // rough calendar padding for weekends

  let d = new Date(start);
  let count = 0;
  while (count < days) {
    d.setDate(d.getDate() + 1);
    const day = d.getDay();
    if (day === 0 || day === 6) continue; // skip weekends, crude trading-day approx

    // volatility clustering: vol mean-reverts toward 0.009 with its own noise
    vol = vol + 0.06 * (0.009 - vol) + 0.0015 * gaussian(rand);
    vol = Math.max(0.003, Math.min(vol, 0.035));

    const drift = 0.0002; // small positive daily drift
    const shock = gaussian(rand) * vol;
    const dailyReturn = drift + shock;

    price = price * (1 + dailyReturn);
    series.push({ date: d.toISOString().slice(0, 10), close: Math.round(price * 100) / 100 });
    count++;
  }

  cachedSeries = series;
  return series;
}
