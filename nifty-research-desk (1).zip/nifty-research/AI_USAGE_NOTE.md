# AI Usage Note

> **Before you submit:** this is a draft reflecting how the assistant (Claude)
> was actually used to build this repo. Read it, edit anything that doesn't
> match what you personally decided or changed, and add your own voice —
> the brief asks specifically what *you* reviewed, rejected, or modified.
> Submitting this unedited would defeat the point of the exercise.

## 1. Which AI tools did I use?

Claude (Anthropic), used conversationally to scaffold and write the Next.js
prototype, and referenced for the LLM-extraction step inside the app itself
(`lib/llm.ts` calls the Anthropic API at runtime).

## 2. What did I use it for?

- Scaffolding the Next.js/TypeScript/Tailwind project structure.
- Writing the first draft of most files: the `Experiment`/`BacktestResult`
  types, the rule-based fallback parser, the backtest engine, the mock data
  generator, the API routes, and the five UI components.
- Drafting the README and Thinking Note structure.
- Verifying the build compiles and smoke-testing both API routes end-to-end
  (`/api/analyze` and `/api/backtest`) with real requests before treating the
  code as done.

## 3. Which important decisions did I make myself?

_(Fill this in based on what you actually decided when reviewing/adapting
this. Suggested things worth deciding for yourself and noting here:)_

- Whether CLARIFY should block the user with required questions vs. surface
  editable assumptions (this repo took the "surface assumptions" approach —
  do you agree with that call, or would you change it?)
- The choice of a fixed holding period over a trailing stop/target for the
  exit rule, and why.
- Which caveats actually matter most for this specific experiment, vs. which
  are boilerplate.
- The visual/interaction design (palette, layout, ledger-style experiment
  card) — review it and make it your own rather than presenting it as
  untouched.

## 4. Did I reject or modify any AI-generated suggestions? Why?

_(Be specific and honest here — this is the most-weighted part of the note
for the reviewer.)_ Two things worth deciding and documenting for yourself:

- The initial cost model was a flat percentage per trade, applied
  symmetrically regardless of trade direction or size — is that a
  simplification you're comfortable defending, or would you change it?
- The mock-data generator uses a fixed seed for reproducibility. Consider
  whether you'd want to expose that seed (or a "regenerate data" option) in
  the UI, and why you would or wouldn't.

## 5. What part of the solution am I most proud of?

_(Your call — candidates for this: the CLARIFY step's editable-assumptions
design, the explicit "what the data shows" vs. "what we conclude" split in
LEARN, or the clean separation between the LLM path and the rule-based
fallback so the app never silently breaks.)_
