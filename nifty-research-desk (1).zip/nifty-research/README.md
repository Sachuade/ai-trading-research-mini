# NIFTY Research Desk

A small prototype for the "AI Full-Stack Developer Intern" challenge (Option 2).
It turns an informal trading question into a structured, testable experiment,
and walks the user through **ASK → CLARIFY → DEFINE → TEST → LEARN**.

See also: [`THINKING_NOTE.md`](./THINKING_NOTE.md) (Part 1) and
[`AI_USAGE_NOTE.md`](./AI_USAGE_NOTE.md).

## The journey

1. **ASK** — the user types a question in plain English, e.g. *"Does buying
   NIFTY after a sharp fall work?"*
2. **CLARIFY** — the system extracts what it can and flags what it had to
   assume (e.g. "sharp" → 1.5% in a day, holding period → 5 days), with a
   short reason for each default. The user can edit any of these before
   moving on — nothing important is silently assumed and hidden.
3. **DEFINE** — the confirmed inputs are shown as a structured experiment:
   instrument, condition, entry, exit, holding period, test period, filters,
   cost assumptions, and a plainly-stated hypothesis.
4. **TEST** — the experiment runs against a simulated 5-year daily price
   series (see [Why simulated data](#why-simulated-data-not-real-nifty-history)).
5. **LEARN** — results are split into **"what the data shows"** (objective
   numbers: trade count, win rate, average return, equity curve vs.
   buy-and-hold) and **"what we can reasonably conclude"** (a qualified
   interpretation that explicitly downgrades itself when the sample is
   small), plus a caveats list and suggested next questions.

## Architecture

```
app/
  page.tsx              orchestrates the 5-stage flow (client component, holds state)
  api/analyze/route.ts  POST { question } -> { experiment, source }
  api/backtest/route.ts POST { experiment } -> BacktestResult
components/
  Stepper.tsx            left-rail progress indicator
  AskForm.tsx             ASK stage
  ClarifyPanel.tsx        CLARIFY stage (editable assumptions)
  ExperimentCard.tsx      DEFINE stage (ledger-style experiment summary)
  ResultsPanel.tsx        LEARN stage (stats, equity curve, interpretation, caveats)
lib/
  types.ts               shared Experiment / BacktestResult schema
  llm.ts                 Anthropic API adapter (question -> structured experiment)
  parser.ts              rule-based fallback parser (works with no API key at all)
  backtest.ts            the actual test: runs an Experiment against mock data
  mockData.ts            deterministic seeded synthetic NIFTY-like price series
  pathUtils.ts           tiny dot-path get/set used by the CLARIFY editor
```

**Why this split:** the "understand the question" step (`llm.ts` /
`parser.ts`) and the "test the experiment" step (`backtest.ts`) know nothing
about each other — they're connected only by the `Experiment` type in
`types.ts`. That means either side can be swapped out later (a real LLM
prompt-chain instead of one call, a real backtesting engine instead of the
mock one, a real market-data feed instead of `mockData.ts`) without touching
the other, which matches how the assignment frames this as one small slice
of a much bigger eventual system.

**Why a rule-based fallback exists at all:** the assignment specifically
warns against "simply creating a chatbot wrapper." Having a working,
transparent, non-LLM path for the CLARIFY step keeps the LLM's job narrow
(structuring language, not deciding numbers) and means the app still fully
functions — including at a live demo with no internet or API key — without
ever silently failing.

### Why simulated data, not real NIFTY history

This environment has no market-data connector, and NSE historical data isn't
reachable from it. Rather than skip the TEST/LEARN stages, `mockData.ts`
generates a deterministic (seeded) synthetic daily series with volatility
clustering, so the backtest has something realistic-shaped to run against.
Every caveat and result in the LEARN stage says explicitly that this is
simulated data — the point of this prototype is the **workflow** (question →
experiment → evidence → next questions), not a real trading signal, which the
assignment brief explicitly allows.

## Technologies used

- **Next.js 14 (App Router) + TypeScript** — one deployable app, API routes
  live next to the UI, no separate backend to stand up for a 3–4 hour build.
- **Tailwind CSS** — utility styling; a small custom palette/typography set
  (see `tailwind.config.ts`, `app/globals.css`) rather than default theme
  colors, so the UI reads as a research tool rather than a generic template.
- **Anthropic API** (`claude-sonnet-4-6`) for the question → experiment
  extraction step, called server-side from `app/api/analyze/route.ts` so the
  API key never reaches the browser.
- No database — a single session's state lives in React state on the client;
  see "What I'd improve" below.

## Running it locally

```bash
npm install
cp .env.example .env.local   # optional: add ANTHROPIC_API_KEY to use the LLM path
npm run dev
```

Without an `ANTHROPIC_API_KEY`, `/api/analyze` automatically uses the
rule-based fallback parser — the app is fully usable either way.

## Key decisions

- **CLARIFY surfaces assumptions instead of blocking on questions.** The
  brief explicitly says "ask the user to clarify rather than blindly making
  important assumptions" — I interpreted the *spirit* of that as "make every
  assumption visible and editable," not "force a modal Q&A before showing
  anything." A trading researcher can glance at proposed defaults and only
  intervene on the ones they disagree with, which is faster than answering a
  form.
- **Non-overlapping trades in the backtest.** After a signal fires and a
  position is opened, the engine skips ahead past that holding period before
  looking for the next signal. This avoids double-counting overlapping
  windows and keeps "number of trades" meaningful, at the cost of a smaller
  sample — a trade-off I call out directly in the LEARN caveats.
- **"What the data shows" vs. "what we conclude" are visually and textually
  separate**, per the brief's explicit instruction to distinguish these. The
  conclusion text also downgrades itself automatically when trade count is
  low, rather than always sounding equally confident.
- **The rule-based parser and the LLM parser share one output schema**
  (`Experiment`), so CLARIFY/DEFINE/TEST/LEARN don't know or care which one
  produced the data.

## What I would improve with more time

- **Persist experiments** (a lightweight DB or even browser storage) so a
  user can come back to a past question, compare two experiments side by
  side, or build a small history of what's been tried — this is explicitly
  part of the platform's long-term vision ("remember what it learned").
- **Multi-turn clarification** instead of a single extraction pass — for a
  genuinely ambiguous question, a real system might ask one question at a
  time rather than presenting a wall of assumptions at once.
- **Parameter sensitivity view**: run the same experiment across a small
  grid of thresholds/holding periods and show how much the conclusion
  wobbles, which would make the "this could easily be overfit" caveat
  concrete instead of just asserted.
- **Real market data**: swap `mockData.ts` for an actual NIFTY historical
  feed once one is available, without changing `backtest.ts`'s interface.
- **Automated tests** for `backtest.ts` (the part with real logic worth
  protecting) — skipped here to stay inside the time-box, but it's the first
  thing I'd add.
