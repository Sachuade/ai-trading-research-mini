"use client";

import { useState } from "react";
import type { Experiment } from "@/lib/types";
import { getPath, setPath } from "@/lib/pathUtils";

export default function ClarifyPanel({
  experiment,
  onConfirm,
}: {
  experiment: Experiment;
  onConfirm: (updated: Experiment) => void;
}) {
  const [draft, setDraft] = useState<Experiment>(experiment);

  const updateField = (field: string, raw: string) => {
    const current = getPath(draft, field);
    const value = typeof current === "number" ? (raw === "" ? 0 : Number(raw)) : raw;
    setDraft(setPath(draft, field, value));
  };

  return (
    <div className="max-w-2xl">
      <h2 className="font-serif text-2xl text-ink">A few things weren't specified.</h2>
      <p className="text-sm text-muted mt-2 leading-relaxed">
        Rather than quietly guessing, here's exactly what we assumed and why. Edit anything before
        we lock in the experiment — nothing here is final until you confirm it.
      </p>

      <div className="mt-6 flex flex-col gap-5">
        {draft.missing.map((m) => {
          const currentValue = getPath(draft, m.field);
          const editable = currentValue !== undefined;

          return (
            <div key={m.field} className="border border-line rounded-sm p-4 bg-white">
              <div className="text-sm text-ink font-medium">{m.question}</div>
              <div className="text-xs text-muted mt-1 leading-relaxed">{m.reason}</div>

              <div className="mt-3 flex items-center gap-2">
                <span className="text-xs text-muted">Assumption:</span>
                {editable ? (
                  <input
                    type={typeof currentValue === "number" ? "number" : "text"}
                    value={currentValue}
                    onChange={(e) => updateField(m.field, e.target.value)}
                    className="border border-line rounded-sm px-2 py-1 text-sm w-56 focus:outline-none focus:ring-2 focus:ring-gold/60"
                  />
                ) : (
                  <span className="text-sm text-ink">{m.assumption}</span>
                )}
              </div>
            </div>
          );
        })}
      </div>

      <button
        onClick={() => onConfirm(draft)}
        className="mt-8 bg-ink text-paper text-sm px-5 py-2.5 rounded-sm"
      >
        Confirm assumptions & define experiment
      </button>
    </div>
  );
}
