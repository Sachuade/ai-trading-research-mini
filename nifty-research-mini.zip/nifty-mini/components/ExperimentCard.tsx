"use client";

import { useState } from "react";
import type { Experiment } from "@/lib/types";

export default function ExperimentCard({
  experiment,
  source,
  onEditAgain,
}: {
  experiment: Experiment;
  source: "llm" | "rule-based-fallback";
  onEditAgain: () => void;
}) {
  const [showPayload, setShowPayload] = useState(false);

  const rows: { label: string; value: string }[] = [
    { label: "Instrument", value: experiment.instrument },
    { label: "Timeframe", value: experiment.timeframe },
    { label: "Entry", value: experiment.condition.label + " → " + experiment.entry },
    { label: "Exit", value: experiment.exit },
    { label: "Holding period", value: `${experiment.holdingPeriodDays} trading days` },
    {
      label: "Variables / filters",
      value: experiment.variables.length > 0 ? experiment.variables.join("; ") : "None",
    },
    { label: "Question", value: experiment.question },
  ];

  // What a future backtesting engine would receive — shown only as a
  // preview (bonus, optional per the brief), never actually executed here.
  const payload = {
    instrument: experiment.instrument,
    timeframe: experiment.timeframe,
    entry: { condition: experiment.condition, action: experiment.entry },
    exit: experiment.exit,
    holdingPeriodDays: experiment.holdingPeriodDays,
    filters: experiment.filters,
    question: experiment.question,
  };

  return (
    <div className="max-w-2xl">
      <div className="flex items-baseline justify-between">
        <h2 className="font-serif text-2xl text-ink">The experiment</h2>
        <span className="text-[11px] text-muted">
          {source === "llm" ? "structured by LLM" : "structured by rule-based fallback"}
        </span>
      </div>

      <blockquote className="mt-3 font-serif text-lg text-ink/90 border-l-2 border-gold pl-4">
        “{experiment.rawQuestion}”
      </blockquote>

      <div className="mt-6 bg-white border border-line rounded-sm px-4">
        {rows.map((r) => (
          <div key={r.label} className="ledger-row">
            <div className="text-xs text-muted uppercase tracking-wide">{r.label}</div>
            <div className="text-sm text-ink leading-relaxed">{r.value}</div>
          </div>
        ))}
      </div>

      <div className="mt-8 flex items-center gap-4">
        <button onClick={onEditAgain} className="text-sm text-muted underline underline-offset-4">
          Revisit assumptions
        </button>
        <button onClick={() => setShowPayload((v) => !v)} className="text-sm text-muted underline underline-offset-4">
          {showPayload ? "Hide" : "Preview"} backtesting-engine payload (bonus)
        </button>
      </div>

      {showPayload && (
        <pre className="mt-4 bg-ink text-paper text-xs p-4 rounded-sm overflow-x-auto leading-relaxed">
          {JSON.stringify(payload, null, 2)}
        </pre>
      )}
    </div>
  );
}
