"use client";

export type Stage = "ask" | "clarify" | "define";

const STAGES: { id: Stage; label: string; hint: string }[] = [
  { id: "ask", label: "Understand", hint: "Read the question" },
  { id: "clarify", label: "Clarify", hint: "Surface what's assumed" },
  { id: "define", label: "Define", hint: "Show the experiment" },
];

export default function Stepper({ current }: { current: Stage }) {
  const currentIndex = STAGES.findIndex((s) => s.id === current);

  return (
    <nav className="flex md:flex-col gap-0 md:w-48 shrink-0" aria-label="Workflow progress">
      {STAGES.map((s, idx) => {
        const done = idx < currentIndex;
        const active = idx === currentIndex;
        return (
          <div
            key={s.id}
            className={`flex md:flex-row items-start gap-3 py-3 md:py-4 border-b md:border-b-0 md:border-l-2 pl-3 md:pl-4 ${
              active ? "border-ink" : done ? "border-gold" : "border-line"
            }`}
          >
            <span className={`text-xs mt-0.5 tabular-nums ${active ? "text-ink" : done ? "text-gold" : "text-muted"}`}>
              {String(idx + 1).padStart(2, "0")}
            </span>
            <div>
              <div className={`font-serif text-base leading-none ${active ? "text-ink" : done ? "text-ink/70" : "text-muted"}`}>
                {s.label}
              </div>
              <div className="hidden md:block text-[11px] text-muted mt-1">{s.hint}</div>
            </div>
          </div>
        );
      })}
    </nav>
  );
}
