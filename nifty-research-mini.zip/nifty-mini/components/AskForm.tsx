"use client";

import { useState } from "react";

const EXAMPLES = [
  "Does buying NIFTY after a sharp fall work?",
  "Does buying NIFTY after a 1% fall have an edge during high-volatility periods?",
  "If NIFTY drops 2% in a day, does it bounce back within a week?",
];

export default function AskForm({
  onSubmit,
  loading,
}: {
  onSubmit: (question: string) => void;
  loading: boolean;
}) {
  const [value, setValue] = useState("");

  return (
    <div className="max-w-2xl">
      <h1 className="font-serif text-3xl leading-snug text-ink">
        Ask a question about the market, in your own words.
      </h1>
      <p className="text-sm text-muted mt-3 leading-relaxed">
        We'll turn it into a structured experiment, tell you what we had to assume, and let you
        test it before drawing any conclusions.
      </p>

      <form
        className="mt-8"
        onSubmit={(e) => {
          e.preventDefault();
          if (value.trim()) onSubmit(value.trim());
        }}
      >
        <textarea
          className="w-full border border-line bg-white rounded-sm p-4 text-sm text-ink leading-relaxed focus:outline-none focus:ring-2 focus:ring-gold/60 min-h-[110px]"
          placeholder="e.g. Does buying NIFTY after a sharp fall work?"
          value={value}
          onChange={(e) => setValue(e.target.value)}
          disabled={loading}
        />
        <button
          type="submit"
          disabled={loading || !value.trim()}
          className="mt-4 bg-ink text-paper text-sm px-5 py-2.5 rounded-sm disabled:opacity-40"
        >
          {loading ? "Reading your question…" : "Turn this into an experiment"}
        </button>
      </form>

      <div className="mt-10">
        <div className="text-xs text-muted mb-2">Or try one of these</div>
        <div className="flex flex-col gap-2 items-start">
          {EXAMPLES.map((ex) => (
            <button
              key={ex}
              onClick={() => onSubmit(ex)}
              disabled={loading}
              className="text-left text-sm text-ink/80 border-b border-dashed border-line hover:border-ink transition-colors"
            >
              {ex}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
