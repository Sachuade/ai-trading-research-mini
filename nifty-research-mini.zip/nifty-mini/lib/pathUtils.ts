// Minimal dot-path set/get, just enough for the handful of nested Experiment
// fields we let the CLARIFY step edit (e.g. "condition.dropPct"). Not a
// general-purpose library on purpose — this app has one small, known shape.

export function setPath(obj: any, path: string, value: any): any {
  const keys = path.split(".");
  const clone = structuredClone(obj);
  let cur = clone;
  for (let i = 0; i < keys.length - 1; i++) {
    cur = cur[keys[i]];
  }
  cur[keys[keys.length - 1]] = value;
  return clone;
}

export function getPath(obj: any, path: string): any {
  return path.split(".").reduce((acc, key) => (acc == null ? acc : acc[key]), obj);
}
