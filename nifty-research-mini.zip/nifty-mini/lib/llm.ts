import type { Experiment } from "./types";

const SYSTEM_PROMPT = `You convert an informal natural-language trading question into a structured research experiment definition.

Return ONLY a single JSON object, no prose, no markdown fences, matching exactly this shape:

{
  "instrument": string,
  "timeframe": string,
  "condition": { "label": string, "dropPct": number, "lookbackDays": number },
  "entry": string,
  "exit": string,
  "holdingPeriodDays": number,
  "filters": { "highVolatilityOnly": boolean, "volatilityLookbackDays": number, "volatilityPercentileThreshold": number },
  "variables": string[],
  "question": string,
  "missing": [ { "field": string, "question": string, "assumption": string | number, "reason": string } ]
}

Rules:
- Only put something in "missing" if the user's question genuinely did not specify it. For each missing item, propose a specific, reasonable default in "assumption" and explain the reasoning in "reason". The main experiment fields must always be fully populated with your best-assumed values — "missing" is a transparency log of which values were assumed rather than stated, not a list of blanks.
- Interpret vague words like "sharp fall" using a specific numeric threshold, and log that interpretation as a "missing" item so the user can see and challenge it.
- "question" should restate, in plain language, what the user is actually trying to find out (e.g. "Does this condition have a positive edge?").
- "variables" is a short free-text list of any other filters or conditions mentioned (e.g. "high volatility only"). Use an empty array if none.
- Only assume NIFTY 50 if no instrument is named.
- Keep "label" fields short and human-readable.
- Do not include any text outside the JSON object.`;

export async function llmParse(question: string): Promise<Experiment | null> {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) return null;

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-6",
        max_tokens: 1000,
        system: SYSTEM_PROMPT,
        messages: [{ role: "user", content: question }],
      }),
    });

    if (!response.ok) {
      console.error("Anthropic API error", await response.text());
      return null;
    }

    const data = await response.json();
    const text = data.content?.map((c: any) => c.text || "").join("") ?? "";
    const cleaned = text.replace(/```json|```/g, "").trim();
    const parsed = JSON.parse(cleaned);

    return { ...parsed, rawQuestion: question } as Experiment;
  } catch (err) {
    console.error("llmParse failed, falling back to rule-based parser", err);
    return null;
  }
}
