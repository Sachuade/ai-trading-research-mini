// Domain model for Option 1. Deliberately smaller than a full backtest
// schema — this assignment only asks us to understand → structure →
// flag-missing-info → display. Testing is an optional bonus, shown here
// only as a preview of the payload a future backtesting engine would
// receive, not an actual test run.

export type MissingField = {
  field: string; // dot-path into Experiment, e.g. "condition.dropPct"
  question: string; // what we'd ask the user
  assumption: string | number; // reasonable default we propose instead of blocking the user
  reason: string; // why we chose that default
};

export type Experiment = {
  instrument: string;
  timeframe: string; // e.g. "Daily"
  condition: {
    label: string; // human-readable, e.g. "NIFTY falls >= 1% in a single day"
    dropPct: number;
    lookbackDays: number;
  };
  entry: string;
  exit: string;
  holdingPeriodDays: number;
  filters: {
    highVolatilityOnly: boolean;
    volatilityLookbackDays: number;
    volatilityPercentileThreshold: number;
  };
  variables: string[]; // free-text list of other filters/variables mentioned or assumed
  question: string; // "what the user is trying to find out", in plain language
  missing: MissingField[];
  rawQuestion: string;
};

export type AnalyzeResponse = {
  experiment: Experiment;
  source: "llm" | "rule-based-fallback";
};
