import type { Experiment, MissingField } from "./types";

// Deliberately simple and transparent: looks for a few obvious signals
// (a percentage figure, the word "volatility", an explicit holding period)
// and otherwise falls back to sane, disclosed defaults. This keeps the
// prototype fully demoable with no API key and no network dependency, and
// gives the LLM path (lib/llm.ts) a deterministic fallback if it fails.

const DEFAULT_DROP_PCT_FOR_SHARP = 1.5;

export function ruleBasedParse(question: string): Experiment {
  const q = question.toLowerCase();
  const missing: MissingField[] = [];

  const instrument = "NIFTY 50";
  if (!/nifty/.test(q)) {
    missing.push({
      field: "instrument",
      question: "Which instrument or index should this test run on?",
      assumption: "NIFTY 50",
      reason: "No instrument was mentioned in the question; NIFTY 50 is the default for this workspace.",
    });
  }

  let dropPct = DEFAULT_DROP_PCT_FOR_SHARP;
  const pctMatch = q.match(/(\d+(\.\d+)?)\s?%/);
  if (pctMatch) {
    dropPct = parseFloat(pctMatch[1]);
  } else if (/sharp|big|large|significant/.test(q)) {
    missing.push({
      field: "condition.dropPct",
      question: `What counts as a "sharp" fall — what percentage drop should trigger the strategy?`,
      assumption: DEFAULT_DROP_PCT_FOR_SHARP,
      reason:
        '"Sharp" is subjective. We used a moderate threshold as a working definition, but this materially changes which days qualify.',
    });
  } else {
    missing.push({
      field: "condition.dropPct",
      question: "What percentage fall should trigger a buy?",
      assumption: DEFAULT_DROP_PCT_FOR_SHARP,
      reason: "No threshold was given, so we used a moderate default.",
    });
  }

  const lookbackDays = /week/.test(q) ? 5 : 1;
  if (!/day|week|session/.test(q)) {
    missing.push({
      field: "condition.lookbackDays",
      question: "Should the fall be measured over a single day, or over a few days/a week?",
      assumption: 1,
      reason: "No timeframe for the fall itself was specified.",
    });
  }

  const highVolatilityOnly = /volatil/.test(q);
  const variables: string[] = [];
  if (highVolatilityOnly) variables.push("High-volatility regime filter (top 30% by 20-day rolling volatility)");

  let holdingPeriodDays = 5;
  const holdMatch = q.match(/hold(ing)?\s*(for|period)?\s*(\d+)\s*(day|days|week|weeks)/);
  if (holdMatch) {
    const n = parseInt(holdMatch[3], 10);
    holdingPeriodDays = /week/.test(holdMatch[4]) ? n * 5 : n;
  } else {
    missing.push({
      field: "holdingPeriodDays",
      question: "How long should the position be held before exiting?",
      assumption: 5,
      reason: "The question didn't specify an exit rule, so we used a short, common holding period as a starting point.",
    });
  }

  const experiment: Experiment = {
    instrument,
    timeframe: "Daily",
    condition: {
      label: `${instrument} falls ${dropPct}% or more${lookbackDays > 1 ? ` over ${lookbackDays} trading days` : " in a single session"}`,
      dropPct,
      lookbackDays,
    },
    entry: "Buy at the next session's close after the condition is met",
    exit: `Sell after the holding period elapses (${holdingPeriodDays} trading days)`,
    holdingPeriodDays,
    filters: {
      highVolatilityOnly,
      volatilityLookbackDays: 20,
      volatilityPercentileThreshold: 70,
    },
    variables,
    question: "Does this condition have a positive edge — on average, and often enough to matter?",
    missing,
    rawQuestion: question,
  };

  return experiment;
}
