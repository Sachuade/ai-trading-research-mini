import { NextRequest, NextResponse } from "next/server";
import { llmParse } from "@/lib/llm";
import { ruleBasedParse } from "@/lib/parser";
import type { AnalyzeResponse } from "@/lib/types";

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null);
  const question = typeof body?.question === "string" ? body.question.trim() : "";

  if (!question) {
    return NextResponse.json({ error: "A question is required." }, { status: 400 });
  }

  const llmResult = await llmParse(question);
  const experiment = llmResult ?? ruleBasedParse(question);
  const source: AnalyzeResponse["source"] = llmResult ? "llm" : "rule-based-fallback";

  return NextResponse.json({ experiment, source } satisfies AnalyzeResponse);
}
