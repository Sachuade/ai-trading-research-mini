# NIFTY Research Assistant — Mini Prototype

A small prototype for the "AI Trading Research Assistant" challenge (Option
1). It turns a plain-English trading question into a structured, reviewable
experiment: **Understand → Clarify → Define**.

## The flow

1. **Understand** — the user types a question, e.g. *"Does buying NIFTY
   after a sharp fall work better during high-volatility periods?"*
2. **Clarify** — the system extracts what it can (instrument, condition,
   filters) and explicitly flags anything it had to assume — a percentage
   threshold for "sharp," a default holding period, etc. — each with a short
   reason. The user can edit any of these before moving on; nothing
   important is silently assumed and hidden.
3. **Define** — the confirmed inputs are shown as a clean, structured
   experiment: instrument, timeframe, entry, exit, holding period,
   variables/filters, and a plain-language restatement of what the user is
   trying to find out.

**Bonus (optional):** the Define screen has a "Preview backtesting-engine
payload" toggle that shows the JSON a future backtesting engine would
receive for this experiment. It's a preview only — nothing is actually
tested, per the assignment's explicit note that this is optional.

## Architecture

```
app/
  page.tsx              orchestrates Understand -> Clarify -> Define (client component)
  api/analyze/route.ts  POST { question } -> { experiment, source }
components/
  Stepper.tsx            3-stage progress indicator
  AskForm.tsx             Understand stage
  ClarifyPanel.tsx        Clarify stage (editable assumptions)
  ExperimentCard.tsx      Define stage + bonus JSON payload preview
lib/
  types.ts               shared Experiment schema
  llm.ts                 Anthropic API adapter (question -> structured experiment)
  parser.ts              rule-based fallback parser (works with no API key at all)
  pathUtils.ts           tiny dot-path get/set used by the Clarify editor
```

**Why a rule-based fallback exists:** the brief warns against "simply
creating a chatbot wrapper." Keeping a transparent, non-LLM extraction path
means the CLARIFY step's job (deciding what to assume, and how to phrase
that to the user) is separated from the LLM's job (parsing loose language),
and the app keeps working — including at a live demo with no internet or API
key — instead of silently failing.

## Technologies used

- **Next.js 14 (App Router) + TypeScript** — a single deployable app with
  the API route living next to the UI, appropriate for a 3–4 hour build.
- **Tailwind CSS** with a small custom palette/typography set (see
  `tailwind.config.ts`, `app/globals.css`) rather than default theme colors,
  so the UI reads as a research tool rather than a generic template.
- **Anthropic API** (`claude-sonnet-4-6`) for the question → experiment
  extraction, called server-side from `app/api/analyze/route.ts` so the API
  key never reaches the browser.

## Running it locally

```bash
npm install
cp .env.example .env.local   # optional: add ANTHROPIC_API_KEY to use the LLM path
npm run dev
```

Without an `ANTHROPIC_API_KEY`, `/api/analyze` automatically uses the
rule-based fallback parser — the app is fully usable either way.

## Key decisions

- **Clarify surfaces assumptions instead of blocking on a form.** The brief
  says to "ask the user to clarify rather than blindly making important
  assumptions." I read that as "make every assumption visible and
  editable," not "force a Q&A wizard before showing anything" — a
  researcher can glance at proposed defaults and only intervene on the ones
  they disagree with.
- **Only genuinely load-bearing gaps are flagged.** The parser doesn't ask
  about every conceivable detail (e.g. weekend handling) — only things that
  would meaningfully change the experiment if answered differently (the
  drop threshold, the holding period, the instrument).
- **The bonus payload is a preview, not a real test.** Actually running a
  backtest was explicitly out of scope for Option 1; showing the exact
  shape of data a backtesting engine would consume demonstrates the
  hand-off point without expanding the deliverable.
- **Rule-based and LLM parsers share one output schema** (`Experiment`), so
  the Clarify/Define UI doesn't know or care which one produced the data.

## What I would improve with more time

- **Multi-turn clarification** for genuinely ambiguous questions, instead of
  a single extraction pass that surfaces every assumption at once.
- **Persisting past experiments** so a user can revisit or compare questions
  they've asked before — part of the platform's long-term "remember what it
  learned" vision.
- **A real backtesting engine** behind the bonus payload preview, plus a
  real market-data feed, once one is available in this environment.
- **Automated tests** for the parser's edge cases (conflicting signals in
  one question, multiple percentages mentioned, etc.).

## AI tools used (short note)

- **Tool:** Claude (Anthropic).
- **Used for:** scaffolding the Next.js/TypeScript project, drafting the
  rule-based parser, the LLM prompt in `lib/llm.ts`, the API route, and the
  UI components; drafting this README.
- **Personally designed / reviewed:** _(fill in based on your own pass over
  this code)_ — worth deciding and noting here: whether Clarify should
  surface assumptions vs. require answers, which gaps are worth flagging at
  all vs. silently assumed, and the visual design. Also worth documenting:
  anything you changed after testing it (e.g. adjusting which regex
  patterns the parser looks for, or tweaking the LLM prompt's wording).
